param(
    [string]$ZipPath = "CandidateID_Workbench.zip"
)
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
$total = $zip.Entries.Count
$corrupted = 0
$backslashCount = 0

foreach ($entry in $zip.Entries) {
    if ($entry.FullName -like "*\*") {
        $backslashCount++
    }
    try {
        $stream = $entry.Open()
        $buffer = New-Object byte[] 65536
        while ($stream.Read($buffer, 0, $buffer.Length) -gt 0) {}
        $stream.Dispose()
    } catch {
        $corrupted++
        Write-Host "Failed CRC on: $($entry.FullName)" -ForegroundColor Red
    }
}
$zip.Dispose()

Write-Host "Total entries in ${ZipPath}: $total" -ForegroundColor Cyan
Write-Host "Backslash separator violations: $backslashCount"
Write-Host "Decompression / CRC errors:     $corrupted"

if ($corrupted -eq 0 -and $backslashCount -eq 0) {
    Write-Host "Archive Integrity Check PASSED (100% OK)" -ForegroundColor Green
} else {
    throw "Archive Integrity Check FAILED"
}
