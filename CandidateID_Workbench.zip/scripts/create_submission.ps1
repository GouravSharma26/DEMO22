# Create Final Submission ZIP
param (
    [string]$CandidateId = "CandidateID",
    [string]$DistDir = "",
    [string]$ZipOutput = "$PSScriptRoot\..\${CandidateId}_Workbench.zip"
)

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
Set-Location $repoRoot

# Resolve distribution directory containing standalone release runtime
if (-not $DistDir) {
    if (Test-Path "$repoRoot\dist\CandidateID_Workbench\Launch.exe") {
        $DistDir = "$repoRoot\dist\CandidateID_Workbench"
    } elseif (Test-Path "$repoRoot\dist\Workbench\Launch.exe") {
        $DistDir = "$repoRoot\dist\Workbench"
    } else {
        $DistDir = "$repoRoot\dist\CandidateID_Workbench"
    }
}

Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host "Creating Comprehensive Candidate Submission Package" -ForegroundColor Cyan
Write-Host "  Repository Root: $repoRoot" -ForegroundColor Cyan
Write-Host "  Runtime Dist:    $DistDir" -ForegroundColor Cyan
Write-Host "  Target Archive:  $ZipOutput" -ForegroundColor Cyan
Write-Host "====================================================================" -ForegroundColor Cyan

# 1. Package standalone release if not done
if (-not (Test-Path "$DistDir\Launch.exe") -or -not (Test-Path "$DistDir\workbench_app.exe")) {
    Write-Host "Standalone release executables not found. Running release packaging..." -ForegroundColor Yellow
    & "$PSScriptRoot\package_release.ps1" -OutputDir $DistDir
}

# 2. Verify verified raw results exist (do not overwrite verified experimental data)
Write-Host "Verifying experimental result CSVs in results/..." -ForegroundColor Yellow
$requiredCsvs = @(
    "thermal_nodal_temperature_N10.csv",
    "thermal_midpoint_errors.csv",
    "thermal_convergence_study.csv",
    "backprop_training_trace_100steps.csv",
    "backprop_gradient_check.csv",
    "benchmark_1000cases_summary.csv",
    "benchmark_raw_timings.csv",
    "serial_parallel_agreement.csv"
)
$missingCsvs = @()
foreach ($csv in $requiredCsvs) {
    if (-not (Test-Path "$repoRoot\results\$csv")) {
        $missingCsvs += $csv
    }
}
if ($missingCsvs.Count -gt 0) {
    Write-Host "Missing CSVs: $($missingCsvs -join ', '). Running native experiments runner..." -ForegroundColor Yellow
    $expRunner = "$repoRoot\build\windows-msvc-x64-release\src\experiments\Release\workbench_experiments.exe"
    if (Test-Path $expRunner) {
        & $expRunner
    }
} else {
    Write-Host "All $($requiredCsvs.Count) authoritative numerical result CSVs verified present." -ForegroundColor Green
}

# 3. Ensure Git history and bundle are updated
Write-Host "Generating readable Git commit history and offline Git bundle..." -ForegroundColor Yellow
git log --graph --oneline --decorate --all > "$repoRoot\COMMIT_HISTORY.txt"

if (Test-Path "$repoRoot\EngiWorkbench.bundle") {
    Remove-Item -Force "$repoRoot\EngiWorkbench.bundle"
}
git bundle create "$repoRoot\EngiWorkbench.bundle" --all

# 4. Stage files into a clean temporary staging directory
$stagingDir = "$repoRoot\dist\staging_${CandidateId}"
if (Test-Path $stagingDir) {
    Remove-Item -Recurse -Force $stagingDir
}
New-Item -ItemType Directory -Force -Path $stagingDir | Out-Null

# A. Stage standalone runtime and Launch.exe at root
Write-Host "Staging standalone runtime dependencies and Launch.exe at root..." -ForegroundColor Yellow
Copy-Item "$DistDir\*" -Destination $stagingDir -Recurse -Force

# B. Stage source, test, data, and result directories
Write-Host "Staging complete C++ source, test, data, and result directories..." -ForegroundColor Yellow
$copyDirs = @("src", "tests", "data", "results", "docs", "packaging", "scripts", ".vscode")
foreach ($d in $copyDirs) {
    $srcPath = "$repoRoot\$d"
    if (Test-Path $srcPath) {
        $destPath = "$stagingDir\$d"
        if (-not (Test-Path $destPath)) {
            New-Item -ItemType Directory -Force -Path $destPath | Out-Null
        }
        Copy-Item "$srcPath\*" -Destination "$destPath\" -Recurse -Force
    }
}

# C. Stage root build files, documentation, and governance files
Write-Host "Staging root configuration, CMake, and governance files..." -ForegroundColor Yellow
$copyFiles = @(
    "CMakeLists.txt",
    "CMakePresets.json",
    "README.md",
    "AGENTS.md",
    "THIRD_PARTY_NOTICES.md",
    "OWNERSHIP.md",
    "COMMIT_HISTORY.txt",
    "EngiWorkbench.bundle",
    ".gitattributes",
    "MANIFEST.txt"
)
foreach ($f in $copyFiles) {
    $filePath = "$repoRoot\$f"
    if (Test-Path $filePath) {
        Copy-Item $filePath -Destination "$stagingDir\$f" -Force
    }
}

# Clean any temporary build/cache files from staging directory
Get-ChildItem -Path $stagingDir -Include *.obj, *.pdb, *.tmp, *.ilk, *.exp, *.lib -Recurse -File | Remove-Item -Force

# 5. Create ZIP archive with standard forward-slash (/) entry hygiene
Write-Host "Compressing unified submission archive to $ZipOutput using standard forward-slash paths..." -ForegroundColor Yellow
if (Test-Path $ZipOutput) {
    Remove-Item -Force $ZipOutput
}

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$zipFileStream = [System.IO.File]::Open($ZipOutput, [System.IO.FileMode]::Create)
$zipArchive = New-Object System.IO.Compression.ZipArchive($zipFileStream, [System.IO.Compression.ZipArchiveMode]::Create)

$stagingDirResolved = (Resolve-Path $stagingDir).Path
$files = Get-ChildItem -Path $stagingDir -Recurse -File
$counter = 0

foreach ($f in $files) {
    $counter++
    $relPath = $f.FullName.Substring($stagingDirResolved.Length).TrimStart('\', '/').Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zipArchive, $f.FullName, $relPath, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
}

$zipArchive.Dispose()
$zipFileStream.Dispose()

# Verify archive path separator hygiene
$verifyZip = [System.IO.Compression.ZipFile]::OpenRead($ZipOutput)
$backslashEntries = $verifyZip.Entries | Where-Object { $_.FullName -like "*\*" }
$totalEntries = $verifyZip.Entries.Count
$verifyZip.Dispose()

if ($backslashEntries.Count -gt 0) {
    throw "Archive hygiene error: found $($backslashEntries.Count) entries with backslash separators."
}
Write-Host "Archive hygiene verified: all $totalEntries entries use conventional forward-slash (/) separators." -ForegroundColor Green

# Cleanup staging directory
Remove-Item -Recurse -Force $stagingDir

# 6. Verification and Checksum
$zipItem = Get-Item $ZipOutput
$zipHash = (Get-FileHash -Path $ZipOutput -Algorithm SHA256).Hash

Write-Host "`n====================================================================" -ForegroundColor Green
Write-Host "Candidate Submission Package Successfully Created!" -ForegroundColor Green
Write-Host "  Archive:  $ZipOutput" -ForegroundColor Green
Write-Host "  Size:     $($zipItem.Length) bytes ($([Math]::Round($zipItem.Length / 1MB, 2)) MB)" -ForegroundColor Green
Write-Host "  SHA256:   $zipHash" -ForegroundColor Green
Write-Host "====================================================================" -ForegroundColor Green

# 7. Verification Test Extraction
Write-Host "`nTesting extraction and root structure verification..." -ForegroundColor Yellow
$verifyDir = "$env:TEMP\verify_${CandidateId}"
if (Test-Path $verifyDir) {
    Remove-Item -Recurse -Force $verifyDir
}
New-Item -ItemType Directory -Force -Path $verifyDir | Out-Null
Expand-Archive -Path $ZipOutput -DestinationPath $verifyDir -Force

$checks = @{
    "Launch.exe" = Test-Path "$verifyDir\Launch.exe"
    "workbench_app.exe" = Test-Path "$verifyDir\workbench_app.exe"
    "platforms\qwindows.dll" = Test-Path "$verifyDir\platforms\qwindows.dll"
    "msvcp140.dll" = Test-Path "$verifyDir\msvcp140.dll"
    "CMakeLists.txt" = Test-Path "$verifyDir\CMakeLists.txt"
    "CMakePresets.json" = Test-Path "$verifyDir\CMakePresets.json"
    "src\core\include\workbench\thermal\solver.hpp" = Test-Path "$verifyDir\src\core\include\workbench\thermal\solver.hpp"
    "src\app\main_window.cpp" = Test-Path "$verifyDir\src\app\main_window.cpp"
    "tests\test_thermal.cpp" = Test-Path "$verifyDir\tests\test_thermal.cpp"
    "results\benchmark_1000cases_summary.csv" = Test-Path "$verifyDir\results\benchmark_1000cases_summary.csv"
    "docs\FINAL_REPORT.md" = Test-Path "$verifyDir\docs\FINAL_REPORT.md"
    "docs\evidence\phase3\01_geometry_view_stl.png" = Test-Path "$verifyDir\docs\evidence\phase3\01_geometry_view_stl.png"
    "docs\evidence\phase4\03_thermal_view_solved.png" = Test-Path "$verifyDir\docs\evidence\phase4\03_thermal_view_solved.png"
    "OWNERSHIP.md" = Test-Path "$verifyDir\OWNERSHIP.md"
    "MANIFEST.txt" = Test-Path "$verifyDir\MANIFEST.txt"
}

$allPass = $true
foreach ($k in $checks.Keys) {
    if ($checks[$k]) {
        Write-Host "  [OK] $k" -ForegroundColor Green
    } else {
        Write-Host "  [FAIL] Missing: $k" -ForegroundColor Red
        $allPass = $false
    }
}

Remove-Item -Recurse -Force $verifyDir

if (-not $allPass) {
    throw "Verification failed: one or more required items were missing from the package."
}

Write-Host "All package structure verification checks passed successfully!" -ForegroundColor Green
