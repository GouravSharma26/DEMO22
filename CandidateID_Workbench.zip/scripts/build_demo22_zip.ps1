param(
    [string]$ZipOut = "..\DEMO22\CandidateID_Workbench.zip"
)

$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
Set-Location $repoRoot

$stagingDir = "$repoRoot\dist\staging_demo22"
if (Test-Path $stagingDir) { Remove-Item -Recurse -Force $stagingDir }
New-Item -ItemType Directory -Force -Path $stagingDir | Out-Null

Write-Host "Staging files for DEMO22 CandidateID_Workbench.zip..." -ForegroundColor Cyan
Copy-Item "$repoRoot\dist\CandidateID_Workbench\*" -Destination $stagingDir -Recurse -Force

$dirs = @("src", "tests", "data", "results", "docs", "packaging", "scripts", ".vscode")
foreach ($d in $dirs) {
    $srcPath = "$repoRoot\$d"
    if (Test-Path $srcPath) {
        $destPath = "$stagingDir\$d"
        if (-not (Test-Path $destPath)) {
            New-Item -ItemType Directory -Force -Path $destPath | Out-Null
        }
        Copy-Item "$srcPath\*" -Destination "$destPath\" -Recurse -Force
    }
}

# In accordance with GitHub's 100 MB limit, replace 572 MB raw video with DEMO_VIDEO_INFORMATION.md
if (Test-Path "$stagingDir\docs\evidence\video\Screen Recording 2026-11-02 072049.mp4") {
    Remove-Item -Force "$stagingDir\docs\evidence\video\Screen Recording 2026-11-02 072049.mp4"
}
Copy-Item "$repoRoot\..\DEMO22\evidence\DEMO_VIDEO_INFORMATION.md" -Destination "$stagingDir\docs\evidence\video\DEMO_VIDEO_INFORMATION.md" -Force

$rootFiles = @(
    "CMakeLists.txt",
    "CMakePresets.json",
    "README.md",
    "AGENTS.md",
    "THIRD_PARTY_NOTICES.md",
    "OWNERSHIP.md",
    "COMMIT_HISTORY.txt",
    "EngiWorkbench.bundle",
    ".gitattributes",
    "MANIFEST.txt",
    "PACK_CONTENTS.md",
    "Handwritten.pdf"
)
foreach ($f in $rootFiles) {
    if (Test-Path "$repoRoot\$f") { Copy-Item "$repoRoot\$f" -Destination "$stagingDir\$f" -Force }
}

Get-ChildItem -Path $stagingDir -Include *.obj, *.pdb, *.tmp, *.ilk, *.exp, *.lib -Recurse -File | Remove-Item -Force

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

if (Test-Path $ZipOut) { Remove-Item -Force $ZipOut }

$zipStream = [System.IO.File]::Open($ZipOut, [System.IO.FileMode]::Create)
$archive = New-Object System.IO.Compression.ZipArchive($zipStream, [System.IO.Compression.ZipArchiveMode]::Create)
$stagingResolved = (Resolve-Path $stagingDir).Path

$allFiles = Get-ChildItem -Path $stagingDir -Recurse -File
foreach ($f in $allFiles) {
    $rel = $f.FullName.Substring($stagingResolved.Length).TrimStart('\', '/').Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $f.FullName, $rel, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
}

$archive.Dispose()
$zipStream.Dispose()
Remove-Item -Recurse -Force $stagingDir

$item = Get-Item $ZipOut
$hash = (Get-FileHash -Path $ZipOut -Algorithm SHA256).Hash

Write-Host "Created DEMO22 Archive: $ZipOut" -ForegroundColor Green
Write-Host "  Size:   $($item.Length) bytes ($([Math]::Round($item.Length / 1MB, 2)) MB)" -ForegroundColor Green
Write-Host "  SHA256: $hash" -ForegroundColor Green
