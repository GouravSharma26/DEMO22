#pragma once

#include <QWidget>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QPushButton>
#include <QLabel>
#include <QTableWidget>
#include "workbench/domain/thermal.hpp"
#include "widgets/plot_widget.hpp"

namespace workbench {
namespace app {

class ThermalView : public QWidget {
    Q_OBJECT

public:
    explicit ThermalView(QWidget* parent = nullptr);

    bool hasSolution() const noexcept { return current_solution_.has_value(); }
    const domain::ThermalSolution& currentSolution() const { return *current_solution_; }
    const std::vector<domain::ConvergenceRecord>& convergenceRecords() const noexcept { return convergence_records_; }

    void setConductivity(double k) { if (k_spin_) k_spin_->setValue(k); }
    void setRodLength(double l) { if (length_spin_) length_spin_->setValue(l); }
    double conductivity() const { return k_spin_ ? k_spin_->value() : 0.0; }
    double rodLength() const { return length_spin_ ? length_spin_->value() : 0.0; }

public slots:
    void onSolveClicked();
    void onConvergenceStudyClicked();
    void onExportNodalCsvClicked();
    void onExportMidpointCsvClicked();
    void onExportConvergenceCsvClicked();

private:
    void setupUi();
    domain::ThermalProblem readInputs() const;
    void updateTemperaturePlot(const domain::ThermalSolution& sol);
    void updateConvergencePlot(const std::vector<domain::ConvergenceRecord>& records);

    // Inputs
    QDoubleSpinBox* length_spin_{nullptr};
    QDoubleSpinBox* area_spin_{nullptr};
    QDoubleSpinBox* k_spin_{nullptr};
    QDoubleSpinBox* q_spin_{nullptr};
    QDoubleSpinBox* t0_spin_{nullptr};
    QDoubleSpinBox* tl_spin_{nullptr};
    QSpinBox* n_spin_{nullptr};

    // Plots
    PlotWidget* temp_plot_{nullptr};
    PlotWidget* conv_plot_{nullptr};

    // Table & Results
    QTableWidget* convergence_table_{nullptr};
    QLabel* summary_label_{nullptr};

    // Cached results for export
    std::optional<domain::ThermalSolution> current_solution_;
    std::vector<domain::ThermalSolution> study_solutions_;
    std::vector<domain::ConvergenceRecord> convergence_records_;
};

} // namespace app
} // namespace workbench

